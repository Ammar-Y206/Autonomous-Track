# Request: البيانات اللي هيرسلها العميل
float32 area_width
float32 area_height
---
# Result: النتيجة النهائية لما الـ Action يخلص
bool success
string message
---
# Feedback: التحديثات اللي هتتبعت أثناء تنفيذ الـ Action
float32 progress_percent
