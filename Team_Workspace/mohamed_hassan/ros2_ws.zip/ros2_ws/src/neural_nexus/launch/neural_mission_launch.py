from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # نود الحساسات
        Node(
            package='neural_nexus',
            executable='sensor_node',
            name='sensor_node',
            output='screen'
        ),

        # نود خدمة الطوارئ
        Node(
            package='neural_nexus',
            executable='emergency_service',
            name='emergency_service',
            output='screen'
        ),

        # نود Action Server لمسح المنطقة
        Node(
            package='neural_nexus',
            executable='scan_action_server',
            name='scan_action_server',
            output='screen'
        ),
    ])
