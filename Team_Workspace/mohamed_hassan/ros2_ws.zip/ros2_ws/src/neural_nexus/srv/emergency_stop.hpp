# Request
bool stop
---
# Response
bool success
string message

