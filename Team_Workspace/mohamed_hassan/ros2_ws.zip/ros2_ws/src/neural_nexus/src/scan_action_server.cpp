#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "neural_nexus/action/scan_area.hpp"
#include <chrono>

using namespace std::chrono_literals;

class ScanActionServer : public rclcpp::Node {
public:
    using Scan = neural_nexus::action::ScanArea;
    using GoalHandleScan = rclcpp_action::ServerGoalHandle<Scan>;

    ScanActionServer() : Node("scan_action_server") {
        action_server_ = rclcpp_action::create_server<Scan>(
            this,
            "scan_area",
            std::bind(&ScanActionServer::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
            std::bind(&ScanActionServer::handle_cancel, this, std::placeholders::_1),
            std::bind(&ScanActionServer::handle_accepted, this, std::placeholders::_1)
        );
    }

private:
    rclcpp_action::Server<Scan>::SharedPtr action_server_;

    rclcpp_action::GoalResponse handle_goal(
        const rclcpp_action::GoalUUID &,
        std::shared_ptr<const Scan::Goal> goal)
    {
        RCLCPP_INFO(get_logger(), "Received goal: duration=%d", goal->duration);
        return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
    }

    rclcpp_action::CancelResponse handle_cancel(
        const std::shared_ptr<GoalHandleScan> goal_handle)
    {
        RCLCPP_INFO(get_logger(), "Goal canceled");
        return rclcpp_action::CancelResponse::ACCEPT;
    }

    void execute(const std::shared_ptr<GoalHandleScan> goal_handle) {
        auto feedback = std::make_shared<Scan::Feedback>();
        auto result = std::make_shared<Scan::Result>();

        int duration = goal_handle->get_goal()->duration;
        for (int i = 0; i <= duration; i++) {
            if (goal_handle->is_canceling()) {
                result->completed = false;
                goal_handle->canceled(result);
                RCLCPP_INFO(get_logger(), "Goal canceled");
                return;
            }
            feedback->percentage = (i * 100.0) / duration;
            goal_handle->publish_feedback(feedback);
            std::this_thread::sleep_for(1s);
        }

        result->completed = true;
        goal_handle->succeed(result);
        RCLCPP_INFO(get_logger(), "Scan completed");
    }

    void handle_accepted(const std::shared_ptr<GoalHandleScan> goal_handle) {
        std::thread{std::bind(&ScanActionServer::execute, this, goal_handle)}.detach();
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<ScanActionServer>());
    rclcpp::shutdown();
    return 0;
}
