#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32.hpp"
#include "std_msgs/msg/string.hpp"
using namespace std::chrono_literals;

class SensorNode : public rclcpp::Node {
public:
    SensorNode() : Node("sensor_node"), battery_(100.0) {
        battery_pub_ = create_publisher<std_msgs::msg::Float32>("battery", 10);
        heartbeat_pub_ = create_publisher<std_msgs::msg::String>("heartbeat", 10);
        timer_ = create_wall_timer(1s, std::bind(&SensorNode::publish_data, this));
    }

private:
    void publish_data() {
        std_msgs::msg::Float32 battery_msg;
        battery_msg.data = battery_;
        battery_pub_->publish(battery_msg);

        std_msgs::msg::String heartbeat_msg;
        heartbeat_msg.data = "alive";
        heartbeat_pub_->publish(heartbeat_msg);

        battery_ -= 1.0;
        if(battery_ < 0.0) battery_ = 100.0;

        RCLCPP_INFO(get_logger(), "Battery: %.2f", battery_);
    }

    float battery_;
    rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr battery_pub_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr heartbeat_pub_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<SensorNode>());
    rclcpp::shutdown();
    return 0;
}
