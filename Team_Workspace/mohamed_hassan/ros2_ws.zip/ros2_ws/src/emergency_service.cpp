#include "rclcpp/rclcpp.hpp"
#include "neural_nexus/srv/emergency_stop.hpp"

class EmergencyService : public rclcpp::Node {
public:
    EmergencyService() : Node("emergency_service") {

        service_ = create_service<neural_nexus::srv::EmergencyStop>(
            "emergency_stop",
            std::bind(&EmergencyService::callback, this,
                      std::placeholders::_1, std::placeholders::_2));
    }

private:
    void callback(
        const std::shared_ptr<neural_nexus::srv::EmergencyStop::Request> request,
        std::shared_ptr<neural_nexus::srv::EmergencyStop::Response> response)
    {
        if(request->stop) {
            RCLCPP_WARN(get_logger(), "EMERGENCY STOP ACTIVATED!");
            response->success = true;
        }
    }

    rclcpp::Service<neural_nexus::srv::EmergencyStop>::SharedPtr service_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<EmergencyService>());
    rclcpp::shutdown();
    return 0;
}
